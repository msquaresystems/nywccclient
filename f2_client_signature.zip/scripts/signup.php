<?php
session_start();
include("dbcon.php");

if(isset($_POST['fname']))
{   
	if(!empty($_POST['reg_email'])){
		$Allready_reg 		= mysql_query("SELECT * FROM  `user` where email ='".$_POST['reg_email']."'");
		$Allready_reg_count = mysql_num_rows($Allready_reg);
		if($Allready_reg_count > 0){
			echo 3;
		}else{
			$firstname= $_POST['fname'];
			$lastname = $_POST['lname'];
			$work     = $_POST['work'];  
			$mob      = $_POST['cell'];
			$username = $_POST['uname'];
			$emailid  = $_POST['reg_email'];
			$pass     = $_POST['passwd'];
			$password = md5($_POST['passwd']);
			$reppass  = md5($_POST['reppasswd']);
			$dob      = $_POST['birthdate'];
			$address  = $_POST['physical_address'];
			$addr_1   = $_POST['physical_address1'];
			$addr_2   = $_POST['physical_address2'];
			$city     = $_POST['physical_city'];
			$state    = $_POST['physical_state'];
			$zip      = $_POST['physical_zip'];
			$country  = $_POST['physical_country'];
			$sql	  = "INSERT INTO user SET firstname='".$firstname."',lastname='".$lastname."',phwork='".$work."',cell='".$mob."',username='".$username."',email='".$emailid."',password='".$password."',reppassword='".$reppass."',dob='".$dob."',physical_address='".$address."',physical_address1='".$addr_1."',physical_address2='".$addr_2."',physical_city='".$city."',physical_state='".$state."',physical_zip='".$zip."',physical_country='".$country."',usertype='user',reg_date=NOW()";                                
			$q		  = mysql_query($sql);
			if($q)
			{
				$userid=mysql_insert_id();
				$to = "$emailid";
				$subject="Your Account activation link";   
				$message.="<html><body>";
				$message.="<table border='0' cellpadding='0' cellspacing'0' width='100%'>";
				$message.="<tr><td style='padding: 10px 0 20px 0;'>";
				$message.="<table align='center' border='0' cellpadding='0' cellspacing='0' width='600' style='border: 1px solid #cccccc; border-collapse: collapse;'>";
				$message.="<tr><td align='center' style='padding: 40px 0 20px 0; color: #fff; font-size: 24px; font-weight: bold; font-family: Arial,sans-serif;' bgcolor='#3BAFE4'>Account Info</td></tr>";
				$message.="<tr><td  style='padding: 40px 30px 20px 30px;' bgcolor='#ffffff'>";
				$message.="<table border='0' cellpadding='0' cellspacing='0' width='100%'>";
				$message.="<tr><td style='padding: 16px 0 10px 0; color: #153643; font-family: Arial, sans-serif; font-size: 14px; line-height: 5px;'>Dear&nbsp;<b>$firstname $lastname,</b></td></tr>";
				$message.="<tr><td style='padding: 16px 0 10px 0; color: #153643; font-family: Arial, sans-serif; font-size: 14px; line-height: 5px;'>You have successfully created your account with <b>M-Squaresystems!</b></td></tr>";
				$message.="<tr><td style='padding: 16px 0 10px 0; color: #153643; font-family: Arial, sans-serif; font-size: 14px; line-height: 5px;'><b>Activation link:</b>&nbsp;<a href='".base_url."activate.php?id=".$userid."'>Click Here</a></td></tr>";
				$message.="<tr><td style='padding: 16px 0 10px 0; color: #153643; font-family: Arial, sans-serif; font-size: 14px; line-height: 5px;'></td>Thank You.</tr>";
				$message.="</table>";
				$message.="</td></tr>";
				$message.="<tr><td style='padding: 30px 30px 30px 30px;' bgcolor='#104C8B'>";
				$message.="<table border='0' cellpadding='0' cellspacing='0' width='100%'>";
				$message.="<tr><td style='color: #ffffff; font-family: Arial, sans-serif; font-size: 14px;' width='75%'>Copyrights 2014 &reg; M-Squaresystems</td></tr>";
				$message.="</table>";
				$message.="</td>";
				$message.="</tr>";
				$message.="</table>";
				$message.="</td></tr>";
				$message.="</table>";
				$message.="</body></html>";
				$headers  = "From:admin@nywcc.com \r\n";
				$headers .= "MIME-Version: 1.0\r\n";
				$headers .= "Content-Type: text/html; charset=utf-8\r\n";   
				$sent=mail($to,$subject,$message,$headers);   
				if($sent){
					echo 1;
				}else{
					echo 0;
				}
			}
		}
	}
 }
                                        
?>