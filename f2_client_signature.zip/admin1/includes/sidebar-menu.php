<div id="cl-wrapper">
		<div class="cl-sidebar">
			<div class="cl-toggle"><i class="fa fa-bars"></i></div>
			<div class="cl-navblock">
				<ul class="cl-vnavigation">
					<li><a href="index.php">Dashboard</a></li>
					<li><a href="clientlist.php">Users</a></li>
					<li><a href="intake.php">Clients</a></li>
					<li><a href="followup.php">Follow</a></li>
					<li><a href="transferacc.php">Transfer Accounts</a></li>
					<li><a href="includes/reports.php"><i class="fa fa-smile-o"></i>Reports</a></li>
					<li><a href="includes/userlogs.php"><i class="fa fa-smile-o"></i>Userlogs</a></li>
				</ul>
			</div>
		</div>