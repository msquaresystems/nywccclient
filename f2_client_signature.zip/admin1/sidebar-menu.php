<div id="cl-wrapper">
		<div class="cl-sidebar">
			<div class="cl-toggle"><i class="fa fa-bars"></i></div>
			<div class="cl-navblock">
				<ul class="cl-vnavigation">
					<li><a href="index.php"><i class="fa fa-home"></i>Dashboard</a></li>
					<li><a href="includes/clientlist.php"><i class="fa fa-smile-o"></i>Users</a></li>
					<li><a href="includes/intake.php"><i class="glyphicon glyphicon-user"></i>Clients</a></li>
					<li><a href="includes/followup.php"><i class=" glyphicon glyphicon-hand-left"></i>Follow</a></li>
					<li><a href="includes/transferacc.php"><i class=" glyphicon glyphicon-transfer"></i>Assign Employees</a></li>
					<li><a href="includes/userlogs.php"><i class="glyphicon glyphicon-floppy-save"></i>Userlogs</a></li>
					<li><a href="includes/reports.php"><i class="fa fa-file"></i>Reports</a></li>
					<li><a href="includes/queries.php"><i class="glyphicon glyphicon-floppy-save"></i>User Queries&emsp;<span class="badge badge-important">6</span></a></li>
				</ul>
			</div>
		</div>